function Car (desc){
this.desc =desc;
this.color ="red";
}

Car.prototype = {
getInfo: function (){
	return "A "+this.color+" "+this.desc+".";
}
};

var car = Object.create(Car.prototype);
//var obj = {};
Object.defineProperties(car,{
	'desc':{value:"Honda Car",writable:true}	
});

Object.defineProperty(car, 'property1', {
value:45,
writable:true, 
enumarable:true,
configurable:true
});
car.color="Blue";
//car.desc = "Honda Car";
alert(car.getInfo());

var obj1 = {soap:'bar',baz:'42'};
if (!Object.entries)
  Object.entries = function( obj1 ){
    var ownProps = Object.keys( obj1 ),
        i = ownProps.length,
        resArray = new Array(i); // preallocate the Array
    while (i--)
      resArray[i] = [ownProps[i], obj[ownProps[i]]];

    return resArray;
  };
console.log(Object.entries(obj1));

var obj2 = ['a','b','c'];
console.log(Object.keys(obj2));

var obj3 = {a:1};
var copy = Object.assign({},  obj3);
console.log(copy);

try{
	addalert("welcome");
} catch(e){
	alert(e);
}


function say667(){
var num = 666;
var sayAlert = function (){
	alert(num);
}
return sayAlert;
}

a.num();